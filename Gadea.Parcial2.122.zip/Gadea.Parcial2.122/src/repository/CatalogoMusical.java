
package repository;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import model.CSVSerializable;

public class CatalogoMusical<T extends CSVSerializable & Comparable<T>> {

    private List<T> inventario = new ArrayList<>();

    public void agregar(T elemento) {
        inventario.add(elemento);
    }

    public T obtener(int indice) {
        return inventario.get(indice);
    }

    public void eliminar(int indice) {
        inventario.remove(indice);
    }

    public List<T> filtrar(Predicate<? super T> criterio) {
        if (criterio == null) {
            throw new NullPointerException("Criterio nulo");
        }
        List<T> resultado = new ArrayList<>();
        for (T item : inventario) {
            if (criterio.test(item)) {
                resultado.add(item);
            }
        }
        return resultado;
    }

    public void ordenar() {
       Collections.sort(inventario, Collections.reverseOrder());
    }

    public void ordenar(Comparator<T> comparador) {
        inventario.sort(comparador);
    }

    public void paraCadaElemento(Consumer<T> accion) {
        inventario.forEach(accion);
    }

    public void guardarEnArchivo(String ruta) {
        try (ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(ruta))) {
            salida.writeObject(inventario);
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

    public void cargarDesdeArchivo(String ruta) throws IOException, ClassNotFoundException {
        try (ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(ruta))) {
            inventario = (List<T>) entrada.readObject();
        }
    }

    public void guardarEnCSV(String ruta) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(ruta))) {
            for (T item : inventario) {
                bw.write(item.toCSV() + "\n");
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

    public void cargarDesdeCSV(String ruta, Function<String, T> parser) {
        inventario.clear();
        try (BufferedReader br = new BufferedReader(new FileReader(ruta))) {
            String aux;
            while ((aux = br.readLine()) != null) {
                inventario.add(parser.apply(aux)); 
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }
}